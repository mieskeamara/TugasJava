/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import database.database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Dosen {
    private String nip;
    private String nama;
    private String tempat_lahir;
    private int no_telp;
    private String alamat;
    
    
    public Dosen(){
        
    }

    public Dosen(String nip, String nama, String tempat_lahir, int no_telp, String alamat) {
        this.nip = nip;
        this.nama = nama;
        this.tempat_lahir = tempat_lahir;
        this.no_telp = no_telp;
        this.alamat = alamat;
    }
      
    
     public void update(){
      String insertQuery = "UPDATE data_dosen SET nama= ? ,tempat_lahir= ? ,no_telp= ? ,alamat= ? WHERE nip= ?";
        database database = new database();
        Connection con = database.getConnection();
        
        try {
            PreparedStatement ps = con.prepareStatement(insertQuery);
            ps.setString(5,this.nip);
            ps.setString(1,this.nama);
            ps.setString(2,this.tempat_lahir);
            ps.setInt(3,this.no_telp);
            ps.setString(4,this.alamat);
            ps.execute();
            System.out.println("Update Data Berhasil");
        } catch (SQLException throwables){
            System.out.println("Update Data Gagal");
            throwables.printStackTrace();
        }  
    }
    
    public void delete(){
        database database = new database();
        Connection con = database.getConnection();
        
        String deleteQuery= "DELETE FROM data_dosen WHERE nip=?";
        
        try{
            PreparedStatement ps = con.prepareStatement(deleteQuery);
            ps.setString(1,this.nip);
            ps.execute();
//            Statement statement = con.createStatement();
//            statement.execute(deleteQuery);
            System.out.println("Hapus Data Berhasil");
        } catch (SQLException throwables){
            System.out.println("Hapus Data Gagal");
            throwables.printStackTrace();
        }
    }
    
    public void delete(String nip){
        database database = new database();
        Connection con = database.getConnection();
        
        String deleteQuery= "DELETE FROM data_dosen WHERE nip=?";
        
        try{
            PreparedStatement ps = con.prepareStatement(deleteQuery);
            ps.setString(1,this.nip);
            ps.execute();
            System.out.println("Hapus Data Berhasil");
        } catch (SQLException throwables){
            System.out.println("Hapus Data Gagal");
            throwables.printStackTrace();
        }
    }
    
      public void read(){
        String selectQuery = "SELECT * FROM data_dosen";
        database database = new database();
        Connection con = database.getConnection();
        
        try {
            Statement statement=con.createStatement();
            ResultSet resultSet = statement.executeQuery(selectQuery);
            
            while(resultSet.next()){
                System.out.println(resultSet.getString("nip"));
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    public void create(){
        String insertQuery = "INSERT INTO data_dosen (nip,nama,tempat_lahir,no_telp,alamat) VALUES (?,?,?,?,?)";
        database database = new database();
        Connection con = database.getConnection();
        
        try {
            PreparedStatement ps = con.prepareStatement(insertQuery);
            ps.setString(1,this.nip);
            ps.setString(2,this.nama);
            ps.setString(3,this.tempat_lahir);
            ps.setInt(4,this.no_telp);
            ps.setString(5,this.alamat);
            ps.execute();
            System.out.println("Tambah Data Berhasil");
        } catch (SQLException throwables){
            System.out.println("Tambah Data Gagal");
            throwables.printStackTrace();
        }
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getTempat_lahir() {
        return tempat_lahir;
    }

    public void setTempat_lahir(String tempat_lahir) {
        this.tempat_lahir = tempat_lahir;
    }

    public int getNo_telp() {
        return no_telp;
    }

    public void setNo_telp(int no_telp) {
        this.no_telp = no_telp;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
    
}
  
