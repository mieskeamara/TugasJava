
package main;
import model.Dosen;
public class Main {
    public static void main(String[] args){
        Dosen dosen = new Dosen("3456","Mieske","banjarbaru",1234,"martapura");
        dosen.update();
    }
}
